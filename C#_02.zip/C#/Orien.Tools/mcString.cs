﻿namespace Orien.Tools {
    public class mcString {
        public static int LastIndexOf(string str, string find_str) => str.LastIndexOf(find_str);
    }
}
