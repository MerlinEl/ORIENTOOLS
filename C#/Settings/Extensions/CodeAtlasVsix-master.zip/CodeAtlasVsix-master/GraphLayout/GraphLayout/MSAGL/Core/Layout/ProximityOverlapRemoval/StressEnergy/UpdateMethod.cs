﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.Msagl.Core.Layout.ProximityOverlapRemoval.StressEnergy {
    /// <summary>
    /// 
    /// </summary>
    public enum UpdateMethod {
        /// <summary>
        /// 
        /// </summary>
        Serial,

        /// <summary>
        /// 
        /// </summary>
        Parallel
    }
}
