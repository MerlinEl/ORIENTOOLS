﻿#if SILVERLIGHT
#else
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;

#if !RAZZLE
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Msagl")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MS")]
[assembly: AssemblyProduct("Msagl")]
[assembly: AssemblyCopyright("Copyright © MS 2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d7e3c4bf-d415-4048-87d2-50437b5b6d24")]

[assembly: InternalsVisibleTo("TestRectilinear, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f552a1c3d4a943c746b9d88a22e64829817eadd9eb21bfd383dc0ac248590ce385bee10618070c472592bc9dfa68428a93991c2a001f70749189cf1e14e66e8d17c6f590088a67147e6c0ad9b2ea917fd397cf08d2893843502b3a3d86888e22ad7429be1e934df07bf28e8fddfb291320a6cb5e5a27096a48a9ef52643949c9")]
[assembly: InternalsVisibleTo("TestForGdi, PublicKey=00240000048000009400000006020000002400005253413100040000010001002397d54023d4ca5633081e178aed1f16acda1e428fc662fdb93f1a800e4578480fc9bb472bf8d3f22d5e91a8db909ae771518b3ccbd49ae4c0781bb459262f76ec99ce28b1655e40ac55909b6c168ba6639ac670dba3a3496c3251c91ad6c6ce31e5ab32e8d4d4ab5fb7ad15a29d7172281066d3d1945412c8027cad49b829b8")]
[assembly: InternalsVisibleTo("Microsoft.Msagl.UnitTests, PublicKey = 0024000004800000940000000602000000240000525341310004000001000100a9ee2081c6e9045e2860859476e48f39716fefb455988366bdd44746194add27839d29aea34ab3df3bf84b56454c4bf92500cd0765372c45675aaa7ec9925fd8ced8aa8cf5a99584ce767ab97249f1170b8c39e5322688701ecb2949314cc4d8b72f62646206d63f05439afd1cfe979da28c5545f0d8c899a8d938777c0fd5c3")]
[assembly: InternalsVisibleTo("GeometryGraphConverter, PublicKey = 00240000048000009400000006020000002400005253413100040000010001000fc03556adc0ce29f5929d07206bb3611c38025dbf160b3de44ebad846b5fc4914d7520e6bfb8249e7c7e1c68c749312502b6c39bfea24c004cab24ecb1ab04f90e8432d3dcc8711fd33486449441f23b823beccbee6754f8ba381c1785b297afd018256d9a4a80d7e395c3dea452cd13ba49f88bd6221db2d895d55295312d6")]
[assembly: InternalsVisibleTo("Test01, PublicKey = 0024000004800000940000000602000000240000525341310004000001000100e3b43db620ddf9733693e320dc708264d4c96bcfabe11cac54c7fb9579327d4e083627bcd9f248423cf3cdab5dfe9f563d0596007163020c349055ce964691463bc101260caa0350aa53bdc3990ea1c17dcedb89a97fddce92c108ba23bba69f31b23393ad7b0ecc55595425285adec585786f274d854f903445b9c0676892d1")]

[assembly: System.Resources.NeutralResourcesLanguage("en-us")]
[assembly: CLSCompliant(true)]
#endif


#endif
