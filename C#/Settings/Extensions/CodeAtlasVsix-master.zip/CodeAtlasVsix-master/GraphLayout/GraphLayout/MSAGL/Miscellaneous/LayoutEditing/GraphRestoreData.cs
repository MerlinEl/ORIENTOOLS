namespace Microsoft.Msagl.Prototype.LayoutEditing {
    internal class GraphRestoreData:RestoreData {
//        internal Rectangle rectangle;
        internal GraphRestoreData() {
           // this.rectangle = rect;
        }
    }
}
