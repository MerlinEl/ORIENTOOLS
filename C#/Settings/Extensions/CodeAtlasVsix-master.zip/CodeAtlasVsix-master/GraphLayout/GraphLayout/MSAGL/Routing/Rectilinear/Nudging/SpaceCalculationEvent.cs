namespace Microsoft.Msagl.Routing.Rectilinear.Nudging{
    internal class SpaceCalculationEvent{
    }
}