namespace Microsoft.Msagl.Routing
{
    internal enum NodeKind {
        Top,
        Internal,
        Bottom
    }

}
