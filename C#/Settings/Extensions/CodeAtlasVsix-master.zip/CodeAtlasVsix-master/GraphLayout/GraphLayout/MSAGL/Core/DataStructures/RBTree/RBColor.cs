namespace Microsoft.Msagl.Core.DataStructures {

    internal enum RBColor {
        Red,
        Black
    }

}
