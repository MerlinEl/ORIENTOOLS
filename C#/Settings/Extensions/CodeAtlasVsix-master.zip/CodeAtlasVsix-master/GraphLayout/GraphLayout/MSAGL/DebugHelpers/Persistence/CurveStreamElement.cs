﻿namespace Microsoft.Msagl.DebugHelpers {
    internal abstract class CurveStreamElement {
        protected internal object Value;
    }
}