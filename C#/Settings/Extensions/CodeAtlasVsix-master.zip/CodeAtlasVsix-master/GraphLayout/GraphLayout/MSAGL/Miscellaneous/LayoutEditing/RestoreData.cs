using System;
using Microsoft.Msagl.Prototype.LayoutEditing;

namespace Microsoft.Msagl.Prototype.LayoutEditing {
    /// <summary>
    /// a base class for restoring geometrical objects
    /// </summary>
    abstract public class RestoreData {
        /// <summary>
        /// 
        /// </summary>
        public Action Action;
    }
}
