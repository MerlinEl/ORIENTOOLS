#if TEST_MSAGL
namespace Microsoft.Msagl.DebugHelpers {
    ///<summary>
    /// shows shapes 
    ///</summary>
    ///<param name="shapes"></param>
    public delegate void ShowDebugCurves(params DebugCurve[] shapes);
}
#endif