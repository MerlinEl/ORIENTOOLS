using System;

namespace Microsoft.Msagl.Core.Layout {
    /// <summary>
    /// At the moment it is an empty class
    /// </summary>
    public class LayoutChangeEventArgs : EventArgs {
        /// <summary>
        /// 
        /// </summary>
        public object DataBeforeChange;
        /// <summary>
        /// 
        /// </summary>
        public object DataAfterChange;
   }
}