﻿using Microsoft.Msagl.Core.Geometry;

namespace Microsoft.Msagl.Core.Layout{
    interface IObstacle {
        Rectangle Rectangle { get; }
    }
}