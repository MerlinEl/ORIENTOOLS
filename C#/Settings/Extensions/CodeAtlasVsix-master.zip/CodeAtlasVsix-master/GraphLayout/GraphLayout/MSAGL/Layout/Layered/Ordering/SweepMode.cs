﻿namespace Microsoft.Msagl.Layout.Layered {
    internal enum SweepMode {
        ComingFromBelow,
        ComingFromAbove,
        Starting
    }
}
