namespace Microsoft.Msagl.Drawing{
    /// <summary>
    /// creates a new node to insert
    /// </summary>
    /// <returns></returns>
    public delegate Node NewNodeFactory();
}