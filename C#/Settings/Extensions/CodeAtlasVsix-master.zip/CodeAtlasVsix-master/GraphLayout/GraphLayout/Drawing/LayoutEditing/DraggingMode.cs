namespace Microsoft.Msagl.Drawing {
    internal enum DraggingMode {
        Default,
        Incremental
    }
}