namespace Microsoft.Msagl.Drawing{
    /// <summary>
    /// A delegate with no parameters and void return type
    /// </summary>
    public delegate void VoidDelegate();
}