﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using AThing;
using CommonInterface;

namespace PlugIn1
{
	/// <summary>
	/// Classes that are instantiated in a separate app domain must be marked as serializable.
	/// In order for the AppDomain to unload, classes must be derived from MarshalByRefObject.
	/// Also note that if the class derives from MarshalByRefObject, it DOES NOT appear in the 
	/// list of assemblies loaded by the application.  If it IS NOT derived from MarshalByRefObject,
	/// then it DOES appear in the list of main application assemblies, and cannot be unloaded!
	/// </summary>
	[Serializable]
	public class PlugIn : MarshalByRefObject, IPlugIn
	{
		private string name;
		private List<Thing> things;
		private MutableListOfThings mutable;

		public string Name { get { return name; } }

		public void Initialize()
		{
			name = "PlugIn 1";
		}

		public void SetThings(List<Thing> things)
		{
			this.things = things;
		}

		public void SetThings(MutableListOfThings mutable)
		{
			this.mutable = mutable;
		}

		public void PrintThings()
		{
			foreach (Thing thing in things)
			{
				Console.WriteLine(thing.Value);
			}
		}

		public void PrintMutableThings()
		{
			for (int i=0; i<mutable.Count; i++)
			{
				Console.WriteLine(mutable[i].Value);
			}
		}

		public void ChangeThings()
		{
			things[2].Value = "Mwahaha!";
		}

		public void ChangeMutableThings()
		{
			mutable[2].Value = "Mutable!";
			mutable.Add(new Thing("D"));
		}

		public void PrintLoadedAssemblies()
		{
			Helpers.PrintLoadedAssemblies();
		}

		public void LoadRuntimeAssembly()
		{
			IDynamicAssembly dassy = DynamicAssemblyLoad();
			dassy.HelloWorld();
		}

		private IDynamicAssembly DynamicAssemblyLoad()
		{
			Assembly assy = AppDomain.CurrentDomain.Load("DynamicallyLoadedByPlugin");
			Type t = assy.GetTypes().SingleOrDefault(assyt => assyt.Name == "LoadMe");

			return Activator.CreateInstance(t) as IDynamicAssembly;
		}
	}
}
