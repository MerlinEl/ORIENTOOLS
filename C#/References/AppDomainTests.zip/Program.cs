﻿using System;
using System.Collections.Generic;
using System.Reflection;

using AThing;
using CommonInterface;

// References:
// https://social.msdn.microsoft.com/Forums/en-US/a6a896ca-8905-41fb-8f52-7f39e89c9a91/problem-loading-and-unloading-dynamically-an-assembly-dll-in-c?forum=csharplanguage
// https://github.com/UAV/PlugInLoader
// http://stackoverflow.com/questions/383686/how-do-you-loop-through-currently-loaded-assemblies
// http://stackoverflow.com/questions/1687245/use-appdomain-to-load-unload-external-assemblies
// https://msdn.microsoft.com/en-us/library/system.marshalbyrefobject(VS.71).aspx
// https://mhusseini.wordpress.com/2013/07/17/loading-assemblies-in-new-appdomain-and-unloading-them/
// https://msdn.microsoft.com/en-us/library/system.loaderoptimization.aspx
// http://stackoverflow.com/questions/313243/how-to-solve-must-be-marshalbyrefobject-in-a-good-but-multiple-inheritance-amp


namespace AppDomainTests
{
	class Program
	{
		static void Main(string[] args)
		{
			// Change to Demo1(), etc., and play around with how Thing is derived.
			Demo1();
		}

		static void Demo1()
		{
			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			IPlugIn plugin1 = InstantiatePlugin("PlugIn1", appDomain1);

			plugin1.Initialize();
			Console.WriteLine(plugin1.Name + "\r\n");

			UnloadPlugin(appDomain1);

			// Try accessing the plug after it has been unloaded.  This should result in an AppDomainUnloadedException.
			TestIfUnloaded(plugin1);
		}

		static void Demo2()
		{
			Helpers.PrintLoadedAssemblies();

			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			IPlugIn plugin1 = InstantiatePlugin("PlugIn1", appDomain1);

			Helpers.PrintLoadedAssemblies();

			plugin1.Initialize();
			Console.WriteLine(plugin1.Name + "\r\n");

			UnloadPlugin(appDomain1);
			Helpers.PrintLoadedAssemblies();

			// Try accessing the plug after it has been unloaded.  This should result in an AppDomainUnloadedException.
			TestIfUnloaded(plugin1);
		}

		static void Demo3()
		{
			Helpers.PrintLoadedAssemblies();

			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			IPlugIn plugin1 = InstantiatePlugin("PlugIn1", appDomain1);

			appDomain1.DomainUnload += OnDomainUnload;

			Helpers.PrintLoadedAssemblies();

			plugin1.Initialize();
			Console.WriteLine(plugin1.Name+"\r\n");

			List<Thing> things = new List<Thing>() { new Thing("A"), new Thing("B"), new Thing("C") };
			plugin1.SetThings(things);
			plugin1.PrintThings();
			Console.WriteLine("\r\n");

			// Now see what happens when we manipulate things.
			things[0].Value = "AA";
			things.Add(new Thing("D"));
			plugin1.PrintThings();
			Console.WriteLine("\r\n");
			// Notice that we get "AA B C".  "D" does not appear because List<T> is not derived from MarshalByRefObject!
			// If we remove the base class MarshalByRefObject from Thing, then we get "A B C" because the list items are passed by value!

			UnloadPlugin(appDomain1);
			Helpers.PrintLoadedAssemblies();

			// Try accessing the plug after it has been unloaded.  This should result in an AppDomainUnloadedException.
			TestIfUnloaded(plugin1);
		}

		static void Demo4()
		{
			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			IPlugIn plugin1 = InstantiatePlugin("PlugIn1", appDomain1);

			Console.WriteLine("Our assemblies:");
			Helpers.PrintLoadedAssemblies();

			plugin1.LoadRuntimeAssembly();
			Console.WriteLine("Their assemblies:");
			plugin1.PrintLoadedAssemblies();
		}

		static void Demo5()
		{
			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			IPlugIn plugin1 = InstantiatePlugin("PlugIn1", appDomain1);
			List<Thing> things = new List<Thing>() { new Thing("A"), new Thing("B"), new Thing("C") };
			plugin1.SetThings(things);
			plugin1.ChangeThings();

			foreach (Thing thing in things)
			{
				Console.WriteLine(thing.Value);
			}
		}

		static void Demo6()
		{
			MutableListOfThings mutable = new MutableListOfThings();
			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			IPlugIn plugin1 = InstantiatePlugin("PlugIn1", appDomain1);
			plugin1.SetThings(mutable);
			mutable.Add(new Thing("A"));
			mutable.Add(new Thing("B"));
			mutable.Add(new Thing("C"));
			plugin1.PrintMutableThings();
			plugin1.ChangeMutableThings();
			Console.WriteLine("\r\n");

			for (int i = 0; i < mutable.Count; i++)
			{
				Console.WriteLine(mutable[i].Value);
			}

			UnloadPlugin(appDomain1);
			Helpers.PrintLoadedAssemblies();

			// Try accessing the plug after it has been unloaded.  This should result in an AppDomainUnloadedException.
			TestIfUnloaded(plugin1);
		}

		static void Demo7()
		{
			DateTime now = DateTime.Now;
			int n = 0;
			IPlugIn plugin1 = new PlugIn1.PlugIn();		// Instantiate in our app domain.
			List<Thing> things = new List<Thing>() { new Thing("A"), new Thing("B"), new Thing("C") };

			while ((DateTime.Now - now).TotalMilliseconds < 1000)
			{
				plugin1.SetThings(things);
				++n;
			}

			Console.WriteLine("Called SetThings {0} times.", n);

			// In a separate appdomain:

			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			plugin1 = InstantiatePlugin("PlugIn1", appDomain1);
			now = DateTime.Now;
			n = 0;

			while ((DateTime.Now - now).TotalMilliseconds < 1000)
			{
				plugin1.SetThings(things);
				++n;
			}

			Console.WriteLine("Called SetThings across AppDomain {0} times.", n);
		}

		static void Demo8()
		{
			DateTime now = DateTime.Now;
			int n = 0;
			IPlugIn plugin1 = new PlugIn1.PlugIn();		// Instantiate in our app domain.
			MutableListOfThings mutable = new MutableListOfThings();
			mutable.Add(new Thing("A"));
			mutable.Add(new Thing("B"));
			mutable.Add(new Thing("C"));

			while ((DateTime.Now - now).TotalMilliseconds < 1000)
			{
				plugin1.SetThings(mutable);
				++n;
			}

			Console.WriteLine("Called SetThings {0} times.", n);

			// In a separate appdomain:

			AppDomain appDomain1 = CreateAppDomain("PlugIn1");
			plugin1 = InstantiatePlugin("PlugIn1", appDomain1);
			now = DateTime.Now;
			n = 0;

			while ((DateTime.Now - now).TotalMilliseconds < 1000)
			{
				plugin1.SetThings(mutable);
				++n;
			}

			Console.WriteLine("Called SetThings across AppDomain {0} times.", n);
		}

		static void OnDomainUnload(object sender, EventArgs e)
		{
			Console.WriteLine("Unloading " + ((AppDomain)sender).FriendlyName);
		}

		static AppDomain CreateAppDomain(string dllName)
		{
			AppDomainSetup setup = new AppDomainSetup() { ApplicationName = dllName, ConfigurationFile = dllName + ".dll.config", ApplicationBase = AppDomain.CurrentDomain.BaseDirectory };
			AppDomain appDomain = AppDomain.CreateDomain(setup.ApplicationName, AppDomain.CurrentDomain.Evidence, setup);

			return appDomain;
		}

		static IPlugIn InstantiatePlugin(string dllName, AppDomain domain)
		{
			IPlugIn plugIn = domain.CreateInstanceAndUnwrap(dllName, dllName + ".PlugIn") as IPlugIn;

			return plugIn;
		}

		static void UnloadPlugin(AppDomain domain)
		{
			AppDomain.Unload(domain);
		}

		static void TestIfUnloaded(IPlugIn plugin)
		{
			bool unloaded = false;

			try
			{
				Console.WriteLine(plugin.Name);
			}
			catch (AppDomainUnloadedException)
			{
				unloaded = true;
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			if (!unloaded)
			{
				Console.WriteLine("It does not appear that the app domain successfully unloaded.");
			}
		}
	}
}
