﻿using System;
using System.Collections.Generic;

using AThing;

namespace CommonInterface
{
    public interface IPlugIn
    {
		string Name { get; }
		void Initialize();
		void SetThings(List<Thing> things);
		void SetThings(MutableListOfThings mutable);
		void PrintThings();
		void PrintLoadedAssemblies();
		void LoadRuntimeAssembly();
		void ChangeThings();
		void PrintMutableThings();
		void ChangeMutableThings();
    }
}
