﻿using System;
using System.Collections.Generic;

using AThing;

namespace CommonInterface
{
	public class MutableListOfThings : MarshalByRefObject
	{
		private List<Thing> things;

		public int Count { get { return things.Count; } }

		public MutableListOfThings()
		{
			things = new List<Thing>();
		}

		public void Add(Thing thing)
		{
			things.Add(thing);
		}

		public Thing this[int n]
		{
			get { return things[n]; }
			set { things[n] = value; }
		}
	}
}
