﻿using System;

namespace CommonInterface
{
	public interface IDynamicAssembly
	{
		void HelloWorld();
	}
}
