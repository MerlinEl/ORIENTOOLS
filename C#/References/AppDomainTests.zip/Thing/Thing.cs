﻿using System;

namespace AThing
{
	// A wrapper.  Must be serializable.
	[Serializable]
    public class Thing : MarshalByRefObject		// If we derive from MarshalByRefObject, then the object is passed by reference, otherwise the object is passed by value, meaning that a copy is made.
    {
		public string Value { get; set; }

		public Thing(string val)
		{
			Value = val;
		}
    }
}
