﻿using System;

using CommonInterface;

namespace DynamicallyLoadedByPlugIn
{
    public class LoadMe : IDynamicAssembly
    {
		public void HelloWorld()
		{
			Console.WriteLine("Hello from an assembly dynamically loaded by a plugin");
		}
    }
}
