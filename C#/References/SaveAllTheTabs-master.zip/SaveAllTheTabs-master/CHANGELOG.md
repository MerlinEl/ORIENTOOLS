---
## Release Notes

### 1.1.0

 - Visual Studio 2017 support (thanks to @toddsay)
 - Bug fixes

### 1.0.0

 - Initial Gallery Release