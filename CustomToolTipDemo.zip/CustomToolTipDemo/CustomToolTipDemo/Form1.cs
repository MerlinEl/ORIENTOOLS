using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CustomToolTipDemo.Properties;

namespace CustomToolTipDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CustomizedToolTip myToolTip1 = new CustomizedToolTip();
            myToolTip1.SetToolTip(button1, "Button 1. ToolTip with Image");

            myToolTip1.SetToolTip(button2, @"Button 2. Formatted string (w/o image)
Created using the verbatim character '@'. End");
            myToolTip1.SetToolTip(button4, @"Button 4. Formatted string (with image)
Created using the verbatim character '@'. End");
            myToolTip1.SetToolTip(button3, "Button 3. ToolTip with Image is being developed by Kumar, Ravikant India");

            button1.Tag = Resources.Image;
            button3.Tag = Resources.Image;
            button4.Tag = Resources.Image;

            propertyGrid1.SelectedObject = myToolTip1;
            propertyGrid1.PropertySort = PropertySort.Alphabetical;
        }
    }
}