﻿using System.Windows.Forms;

namespace Orien.NetUi {
    class mcTest {
        public mcTest() {

           
        }
 
    }
}
