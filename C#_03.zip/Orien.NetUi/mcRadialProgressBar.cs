﻿namespace Orien.NetUi {
    public class mcRadialProgressBar  extends Activity {
        public mcRadialProgressBar() {
        }
    }
}